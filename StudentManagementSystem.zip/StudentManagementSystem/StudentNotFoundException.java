/**
 * Custom checked exception thrown when a student ID does not exist.
 */
public class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String id) {
        super("No student found with ID: " + id);
    }
}
