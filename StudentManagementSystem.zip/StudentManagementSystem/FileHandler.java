import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles saving and loading student data using FILE I/O,
 * so data is not lost when the program closes.
 */
public class FileHandler {

    public static void save(List<Student> students, String fileName) throws IOException {
        // try-with-resources closes the writer automatically
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Student s : students) {
                writer.write(s.toFileString());
                writer.newLine();
            }
        }
    }

    public static List<Student> load(String fileName) throws IOException {
        List<Student> list = new ArrayList<>();
        File file = new File(fileName);
        if (!file.exists()) {
            return list;   // first run: nothing to load
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                try {
                    list.add(Student.fromFileString(line));
                } catch (InvalidInputException | NumberFormatException e) {
                    System.out.println("Skipped a bad record: " + e.getMessage());
                }
            }
        }
        return list;
    }
}
