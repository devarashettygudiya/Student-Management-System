import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Business logic of the system (separate from the user interface).
 * Uses COLLECTIONS: ArrayList, TreeMap and Comparator for sorting.
 */
public class StudentManager {

    private List<Student> students = new ArrayList<>();

    public void setStudents(List<Student> students) { this.students = students; }
    public List<Student> getStudents() { return students; }
    public int count() { return students.size(); }

    public void addStudent(Student s) throws InvalidInputException {
        for (Student existing : students) {
            if (existing.getId().equalsIgnoreCase(s.getId())) {
                throw new InvalidInputException("ID '" + s.getId() + "' already exists.");
            }
        }
        students.add(s);
    }

    public Student findById(String id) throws StudentNotFoundException {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(id)) {
                return s;
            }
        }
        throw new StudentNotFoundException(id);
    }

    public void removeStudent(String id) throws StudentNotFoundException {
        Student s = findById(id);
        students.remove(s);
    }

    public List<Student> searchByName(String keyword) {
        List<Student> result = new ArrayList<>();
        for (Student s : students) {
            if (s.getName().toLowerCase().contains(keyword.toLowerCase())) {
                result.add(s);
            }
        }
        return result;
    }

    public List<Student> sortedByName() {
        List<Student> copy = new ArrayList<>(students);
        copy.sort(Comparator.comparing(Student::getName, String.CASE_INSENSITIVE_ORDER));
        return copy;
    }

    public List<Student> sortedByAverage() {
        List<Student> copy = new ArrayList<>(students);
        copy.sort(Comparator.comparingDouble(Student::calculateAverage).reversed());
        return copy;
    }

    /** Returns the student with the highest average, or null if none. */
    public Student getTopper() {
        Student topper = null;
        for (Student s : students) {
            if (s.getMarks().isEmpty()) continue;
            if (topper == null || s.calculateAverage() > topper.calculateAverage()) {
                topper = s;
            }
        }
        return topper;
    }

    public double classAverage() {
        double total = 0;
        int counted = 0;
        for (Student s : students) {
            if (!s.getMarks().isEmpty()) {
                total += s.calculateAverage();
                counted++;
            }
        }
        return counted == 0 ? 0.0 : total / counted;
    }

    /** Counts how many students got each grade (TreeMap keeps grades sorted). */
    public Map<String, Integer> gradeDistribution() {
        Map<String, Integer> dist = new TreeMap<>();
        for (Student s : students) {
            String g = s.getGrade();
            dist.put(g, dist.getOrDefault(g, 0) + 1);
        }
        return dist;
    }
}
