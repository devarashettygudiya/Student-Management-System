/**
 * Custom checked exception for invalid user input or duplicate data.
 */
public class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}
