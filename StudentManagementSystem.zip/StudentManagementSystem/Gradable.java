/**
 * Interface: defines a "contract" for anything that can be graded.
 * Demonstrates ABSTRACTION through interfaces.
 */
public interface Gradable {
    double calculateAverage();
    String getGrade();
}
