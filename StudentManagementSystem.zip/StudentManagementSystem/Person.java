/**
 * Abstract base class for all people in the system.
 * Demonstrates ABSTRACTION and ENCAPSULATION (private fields + getters/setters).
 */
public abstract class Person {
    private String id;
    private String name;
    private String email;

    public Person(String id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    // Getters and setters (encapsulation)
    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }

    // Abstract method: every subclass MUST provide its own version
    public abstract String getRole();
}
