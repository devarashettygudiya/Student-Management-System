import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Entry point: menu-driven console interface.
 * Shows loops, switch, input validation and exception handling.
 */
public class Main {

    private static final String DATA_FILE = "students.txt";
    private static Scanner sc = new Scanner(System.in);
    private static StudentManager manager = new StudentManager();

    public static void main(String[] args) {
        // Load saved data at startup
        try {
            manager.setStudents(FileHandler.load(DATA_FILE));
            System.out.println("Loaded " + manager.count() + " student(s) from file.");
        } catch (IOException e) {
            System.out.println("Could not load data: " + e.getMessage());
        }

        int choice;
        do {
            printMenu();
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1:  addStudent();       break;
                case 2:  viewAll();          break;
                case 3:  searchById();       break;
                case 4:  searchByName();     break;
                case 5:  updateStudent();    break;
                case 6:  addMarks();         break;
                case 7:  deleteStudent();    break;
                case 8:  sortStudents();     break;
                case 9:  showStatistics();   break;
                case 10: reportCard();       break;
                case 0:  System.out.println("Data saved. Goodbye!"); break;
                default: System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 0);
    }

    // ---------- Menu ----------
    private static void printMenu() {
        System.out.println("\n==========================================");
        System.out.println("      STUDENT MANAGEMENT SYSTEM");
        System.out.println("==========================================");
        System.out.println(" 1. Add Student");
        System.out.println(" 2. View All Students");
        System.out.println(" 3. Search by ID");
        System.out.println(" 4. Search by Name");
        System.out.println(" 5. Update Student Details");
        System.out.println(" 6. Add / Update Marks");
        System.out.println(" 7. Delete Student");
        System.out.println(" 8. Sort Students (Name / Average)");
        System.out.println(" 9. Class Statistics");
        System.out.println("10. Report Card");
        System.out.println(" 0. Save & Exit");
        System.out.println("------------------------------------------");
    }

    // ---------- Features ----------
    private static void addStudent() {
        String id = readNonEmpty("Enter ID: ");
        String name = readNonEmpty("Enter name: ");
        String email = readNonEmpty("Enter email: ");
        if (!email.contains("@") || !email.contains(".")) {
            System.out.println("Error: invalid email format.");
            return;
        }
        String dept = readNonEmpty("Enter department: ");
        try {
            manager.addStudent(new Student(id, name, email, dept));
            save();
            System.out.println("Student added successfully.");
        } catch (InvalidInputException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewAll() {
        printList(manager.getStudents());
    }

    private static void searchById() {
        try {
            Student s = manager.findById(readNonEmpty("Enter ID to search: "));
            printHeader();
            System.out.println(s);
        } catch (StudentNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void searchByName() {
        List<Student> found = manager.searchByName(readNonEmpty("Enter name (or part): "));
        printList(found);
    }

    private static void updateStudent() {
        try {
            Student s = manager.findById(readNonEmpty("Enter ID to update: "));
            System.out.println("Leave a field blank to keep the current value.");

            System.out.print("New name [" + s.getName() + "]: ");
            String name = sc.nextLine().trim();
            if (!name.isEmpty()) s.setName(name);

            System.out.print("New email [" + s.getEmail() + "]: ");
            String email = sc.nextLine().trim();
            if (!email.isEmpty()) s.setEmail(email);

            System.out.print("New department [" + s.getDepartment() + "]: ");
            String dept = sc.nextLine().trim();
            if (!dept.isEmpty()) s.setDepartment(dept);

            save();
            System.out.println("Student updated.");
        } catch (StudentNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void addMarks() {
        try {
            Student s = manager.findById(readNonEmpty("Enter student ID: "));
            String subject = readNonEmpty("Enter subject: ");
            int mark = readInt("Enter marks (0-100): ");
            s.addMark(subject, mark);
            save();
            System.out.println("Marks recorded. New average: "
                    + String.format("%.2f", s.calculateAverage()) + " (" + s.getGrade() + ")");
        } catch (StudentNotFoundException | InvalidInputException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteStudent() {
        try {
            String id = readNonEmpty("Enter ID to delete: ");
            Student s = manager.findById(id);
            System.out.print("Delete " + s.getName() + "? (y/n): ");
            if (sc.nextLine().trim().equalsIgnoreCase("y")) {
                manager.removeStudent(id);
                save();
                System.out.println("Student deleted.");
            } else {
                System.out.println("Cancelled.");
            }
        } catch (StudentNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void sortStudents() {
        System.out.println("1. By Name (A-Z)   2. By Average (high to low)");
        int opt = readInt("Choose: ");
        if (opt == 1) {
            printList(manager.sortedByName());
        } else if (opt == 2) {
            printList(manager.sortedByAverage());
        } else {
            System.out.println("Invalid option.");
        }
    }

    private static void showStatistics() {
        if (manager.count() == 0) {
            System.out.println("No students yet.");
            return;
        }
        System.out.println("\n--- Class Statistics ---");
        System.out.println("Total students : " + manager.count());
        System.out.printf("Class average  : %.2f%n", manager.classAverage());
        Student top = manager.getTopper();
        if (top != null) {
            System.out.printf("Topper         : %s (%.2f)%n", top.getName(), top.calculateAverage());
        }
        System.out.println("Grade distribution:");
        for (Map.Entry<String, Integer> e : manager.gradeDistribution().entrySet()) {
            StringBuilder bar = new StringBuilder();
            for (int i = 0; i < e.getValue(); i++) bar.append("#");
            System.out.printf("  %-4s %s (%d)%n", e.getKey(), bar, e.getValue());
        }
    }

    private static void reportCard() {
        try {
            Student s = manager.findById(readNonEmpty("Enter student ID: "));
            System.out.println("\n========== REPORT CARD ==========");
            System.out.println("Name       : " + s.getName());
            System.out.println("ID         : " + s.getId());
            System.out.println("Department : " + s.getDepartment());
            System.out.println("Email      : " + s.getEmail());
            System.out.println("---------------------------------");
            if (s.getMarks().isEmpty()) {
                System.out.println("No marks recorded yet.");
            } else {
                for (Map.Entry<String, Integer> e : s.getMarks().entrySet()) {
                    System.out.printf("%-20s %3d%n", e.getKey(), e.getValue());
                }
                System.out.println("---------------------------------");
                System.out.printf("Average : %.2f%n", s.calculateAverage());
                System.out.println("Grade   : " + s.getGrade());
            }
            System.out.println("=================================");
        } catch (StudentNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ---------- Helpers ----------
    private static void printHeader() {
        System.out.printf("%-8s %-20s %-12s %-8s %-6s%n", "ID", "Name", "Department", "Average", "Grade");
        System.out.println("---------------------------------------------------------");
    }

    private static void printList(List<Student> list) {
        if (list.isEmpty()) {
            System.out.println("No students to display.");
            return;
        }
        printHeader();
        for (Student s : list) {
            System.out.println(s);
        }
    }

    private static void save() {
        try {
            FileHandler.save(manager.getStudents(), DATA_FILE);
        } catch (IOException e) {
            System.out.println("Warning: could not save data - " + e.getMessage());
        }
    }

    /** Keeps asking until the user types a valid whole number. */
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    /** Keeps asking until the user types something non-empty. */
    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("This field cannot be empty.");
        }
    }
}
