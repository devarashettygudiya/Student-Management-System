import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Student class.
 * INHERITANCE : extends Person
 * INTERFACE   : implements Gradable
 * POLYMORPHISM: overrides getRole(), calculateAverage(), getGrade(), toString()
 */
public class Student extends Person implements Gradable {

    private String department;
    private Map<String, Integer> marks;   // subject -> marks

    public Student(String id, String name, String email, String department) {
        super(id, name, email);          // call parent constructor
        this.department = department;
        this.marks = new LinkedHashMap<>(); // keeps insertion order
    }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public Map<String, Integer> getMarks() { return marks; }

    /** Adds or updates marks for a subject. Validates range 0-100. */
    public void addMark(String subject, int mark) throws InvalidInputException {
        if (subject == null || subject.trim().isEmpty()) {
            throw new InvalidInputException("Subject name cannot be empty.");
        }
        if (mark < 0 || mark > 100) {
            throw new InvalidInputException("Marks must be between 0 and 100.");
        }
        marks.put(subject.trim(), mark);
    }

    @Override
    public String getRole() {
        return "Student";
    }

    @Override
    public double calculateAverage() {
        if (marks.isEmpty()) {
            return 0.0;
        }
        int total = 0;
        for (int m : marks.values()) {
            total += m;
        }
        return (double) total / marks.size();
    }

    @Override
    public String getGrade() {
        if (marks.isEmpty()) return "N/A";
        double avg = calculateAverage();
        if (avg >= 90) return "A+";
        else if (avg >= 80) return "A";
        else if (avg >= 70) return "B";
        else if (avg >= 60) return "C";
        else if (avg >= 50) return "D";
        else return "F";
    }

    /** Converts this student into one line of text for saving to a file. */
    public String toFileString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getId()).append("|").append(getName()).append("|")
          .append(getEmail()).append("|").append(department).append("|");
        boolean first = true;
        for (Map.Entry<String, Integer> e : marks.entrySet()) {
            if (!first) sb.append(";");
            sb.append(e.getKey()).append(":").append(e.getValue());
            first = false;
        }
        return sb.toString();
    }

    /** Rebuilds a Student from one line of the save file. */
    public static Student fromFileString(String line) throws InvalidInputException {
        String[] parts = line.split("\\|", -1);
        if (parts.length < 5) {
            throw new InvalidInputException("Corrupt record: " + line);
        }
        Student s = new Student(parts[0], parts[1], parts[2], parts[3]);
        if (!parts[4].isEmpty()) {
            for (String pair : parts[4].split(";")) {
                String[] kv = pair.split(":");
                s.addMark(kv[0], Integer.parseInt(kv[1]));
            }
        }
        return s;
    }

    @Override
    public String toString() {
        return String.format("%-8s %-20s %-12s %-8.2f %-6s",
                getId(), getName(), department, calculateAverage(), getGrade());
    }
}
